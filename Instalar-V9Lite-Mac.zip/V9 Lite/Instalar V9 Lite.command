#!/bin/bash
# Instalador do V9 Lite para Mac (dois cliques). Baixa e roda o instalador oficial; para atualizar, é só abrir de novo.
clear
echo ""
echo "  V9 Lite · instalador para Mac"
echo "  -----------------------------"
echo "  Vou baixar e instalar (ou atualizar) o V9 Lite. Seus vídeos e a configuração ficam."
echo ""
if ! curl -fsSL https://raw.githubusercontent.com/Hardyrx/v9lite-dist/main/instalar_mac.sh | bash; then
  echo ""
  echo "  A instalação parou. Confira a internet e abra este arquivo de novo."
fi
echo ""
read -r -p "  Aperte Enter para fechar esta janela " _
